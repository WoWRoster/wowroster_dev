<?php
/**
 * WoWRoster.net WoWRoster
 *
 *
 * @copyright  2002-2011 WoWRoster.net
 * @license    http://www.gnu.org/licenses/gpl.html   Licensed under the GNU General Public License v3.
 * @version    SVN: $Id: events.php 2405 2012-02-23 22:25:41Z ulminia@gmail.com $
 * @link       http://www.wowroster.net
 * @package    MembersList
 * @subpackage MemberList Plugins
 */

class events
{

	var $output;
	
	/*
	*	These Vars are used with the new Plugin installer 
	*	@var name - unique name for the plugin
	*	@var parent - the intended addon to use this plugin
	*
	*/
	var $active = true;
	var $name = 'events';
	var $filename = 'main-guild-events.php';
	var $parent = 'main';
	var $icon = 'achievement_worldevent_childrensweek';
	var $version = '1.0';
	var $oldversion = '';
	var $wrnet_id = '';

	var $fullname = 'WoW Events';
	var $description = 'Displays imgame wow events on your page.';
	var $credits = array(
		array(	"name"=>	"Ulminia <Ulminia@gmail.com>",
				"info"=>	"Guild Rep (Alpha Release)"),
	);
	var $events = array(
		'Harvest Festival' => array( 'start' => '2011/09/06', 'end' => '2011/09/13'),
		'Pirates\' Day' => array( 'start' => '2011/09/19', 'end' => '2011/09/20'),
		'Brewfest' => array( 'start' => '2011/09/20', 'end' => '2011/10/05'),
		'Hallow\'s End' => array( 'start' => '2011/10/18', 'end' => '2011/10/31'),
		'Day of the Dead' => array( 'start' => '2011/11/01', 'end' => '2011/11/02'),
		'Pilgrim\'s Bounty' => array( 'start' => '2011/11/20', 'end' => '2011/11/26'),
		'Feast of Winter Veil' => array( 'start' => '2011/12/15', 'end' => '2012/01/02'),
		'Lunar Festival' => array( 'start' => '2012/01/22', 'end' => '2012/02/11'),
		'Love is in the Air' => array( 'start' => '2012/02/05', 'end' => '2012/02/20'),
		'Noblegarden' => array( 'start' => '2012/04/08', 'end' => '2012/04/15'),
		'Children\'s Week' => array( 'start' => '2012/04/29', 'end' => '2012/05/06'),
		'Midsummer Fire Festival' => array( 'start' => '2012/06/21', 'end' => '2012/07/05'),
		'Darkmoon Faire' => array( 'start' => '2012/05/06', 'end' => '2012/05/12'),
		'Fireworks Spectacular' => array( 'start' => '2012/07/04', 'end' => '2012/07/04')
	);
	/*
	*	__construct
	*	this is there the veriables for the addons are 
	*	set in the plugin these are unique to each addon 
	*
	*	contact the addon author is you have a sugestion 
	*	as to where plugin code should occure or use there descression
	*/
	
	public function __construct()
	{
		global $roster;
		
		$this->display();
	}
	
	function getNEXTEVENT()
	{
		foreach ($this->events as $event_name => $event)
		{
			$dateParts = explode('/', $this->events[$event_name]['start']);
										//m					d				y
			$currentTime = time();
			$Time = mktime(0, 0, 0, $dateParts[1], $dateParts[2], $dateParts[0]);
			if($Time > $currentTime)
			{
				$image = str_replace(" ", "", $event_name);
				$image = str_replace("'", "", $image);
				
				return '<center>'.$event_name.'<br><img src="plugins\events'.DIR_SEP.$image.'.png"></a><br> Starts '.gmdate("M d Y", $Time).'</center>';
				break;
			}
		}


    return false;
	}
	function createDateRangeArray($start, $end) 
	{
		// Modified by JJ Geewax 

		$range = array();

		if (is_string($start) === true) $start = strtotime($start);
		if (is_string($end) === true ) $end = strtotime($end);

		if ($start > $end) return $this->createDateRangeArray($end, $start);

		do
		{
			$range[] = date('Y/m/d', $start);
			$start = strtotime("+ 1 day", $start);
		}
		while($start < $end);

		return $range;
	}
	
	function date_change($date)
	{
		$date = new DateTime($date);
		return $date->format('M j');
	}

	function display ()
	{
		$output='';
		$even = false;
		foreach ($this->events as $event_name => $event)
		{
			//echo $event_name.'<br>';
			//now see if its the current event
			$e = $this->createDateRangeArray($this->events[$event_name]['start'], $this->events[$event_name]['end']);
			if (in_array(date('Y/m/d'), $e)) 
			{
				$even = true;
				$image = str_replace(" ", "", $event_name);
				$image = str_replace("'", "", $image);

//$output .='<img src="events/'.$image.'.png"></a>';
				//$output .=''.$this->date_change($this->events[$event_name]['start']).' - '.$this->date_change($this->events[$event_name]['end']);
				//$output .= '<div style="display:block;position:relative;width:91px;height:91px;background:transparent url(events/'.$image.'.png) no-repeat;top:10px;left:10px;"></div>';
				$dateParts1 = explode('/', $this->events[$event_name]['start']);
				$dateParts2 = explode('/', $this->events[$event_name]['end']);
										//m					d				y
				$Time1 = mktime(0, 0, 0, $dateParts1[1], $dateParts1[2], $dateParts1[0]);
				$Time2 = mktime(0, 0, 0, $dateParts2[1], $dateParts2[2], $dateParts2[0]);
$output .= '<center>'.$event_name.'<br><img src="plugins\events'.DIR_SEP.$image.'.png"></a><br> From: '.gmdate("M d Y", $Time1).'<br />To: '.gmdate("M d Y", $Time2).'</center>';

			}
		
		}
		if ($even)
		{
			$this->output = $output;
		}
		else
		{
			$this->output = $this->getNEXTEVENT();
		}
	}
	
	

	
}
abstract class events_function
{
	public function events ( $row, $field )
	{
		global $roster, $member_list_where;

		if (isset($row['curr_rep']))
		{
			$percentage = round(($row['curr_rep']/$row['max_rep'])*100);
			$toolTip = ' ['.$row['curr_rep'].' / '.$row['max_rep'].' ] ';
			$toolTiph = $row['Standing'];
			$tooltip = makeOverlib($toolTip,$toolTiph,'',2,'',',WRAP');
			$cell_value = '<div ' . $tooltip . ' style="cursor:default;"><div class="levelbarParent" style="width:70px;"><div class="levelbarChild">' . $row['Standing'] . '</div></div>';
			$cell_value .= '<table class="expOutline" border="0" cellpadding="0" cellspacing="0" width="70">';
			$cell_value .= '<tr>';
			$cell_value .= '<td style="background-image: url(\'' . $roster->config['theme_path'] . '/images/bars/' . strtolower($row['Standing']).'.gif\');" width="' . $percentage . '%"><img src="' . $roster->config['img_url'] . 'pixel.gif" height="14" width="1" alt="" /></td>';
			$cell_value .= '<td width="' . (100 - $percentage) . '%"></td>';
			$cell_value .= "</tr>\n</table>\n</div>\n";
		
			return '<div style="display:none;">' . str_pad($row['Standing'],2,'0',STR_PAD_LEFT) . '</div>' . $cell_value;
		}
		else
		{
			$cell_value = '';//'<div ' . $tooltip . ' style="cursor:default;">' . $row['Standing'] . '</div>';
			return $cell_value;
		}
	}
}

	
?>